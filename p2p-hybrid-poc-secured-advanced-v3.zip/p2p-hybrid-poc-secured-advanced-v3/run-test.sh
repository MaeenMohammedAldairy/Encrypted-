#!/bin/bash
# run test (requires server running)
node test/test-runner.js
