// test/test-runner.js
// Node.js script to run a sequence of API calls against the local server (HTTPS self-signed)
// Creates users alice and bob, logs them in, registers keys (uses naive generated JWKs here for automation), sends a message, fetches messages.
const https = require('https');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const SERVER = process.env.SERVER || 'https://localhost:3443';

// axios instance to accept self-signed cert for local testing
const httpsAgent = new https.Agent({ rejectUnauthorized: false });
const client = axios.create({ httpsAgent, baseURL: SERVER, timeout: 5000 });

async function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

async function registerUser(userId, password){
  console.log('Registering', userId);
  const resp = await client.post('/auth/register', { userId, password });
  console.log('->', resp.data);
}

async function loginUser(userId, password){
  console.log('Logging in', userId);
  const resp = await client.post('/auth/login', { userId, password });
  console.log('-> token? ', !!resp.data.token);
  return resp.data.token;
}

// For automation: create simple JWK-like public key by generating RSA key pair with node crypto and exporting public key components is complex.
// Instead, we'll use a small helper: register a dummy JWK (not used for real crypto in this test) to exercise server flows.
async function registerPublicKey(userId, token){
  const dummyJwk = { kty: 'RSA', alg: 'RSA-OAEP', use: 'enc', n: '0', e: 'AQAB' };
  const resp = await client.post('/register-key', { userId, publicKeyJwk: dummyJwk }, { headers: { Authorization: 'Bearer ' + token } });
  console.log('register-key ->', resp.data);
}

async function sendMessage(from, to, token){
  // dummy encrypted payloads to exercise server
  const payload = {
    from, to,
    encryptedKeyB64: Buffer.from('deadbeef').toString('base64'),
    ivB64: Buffer.from('iviviviviviv').toString('base64'),
    ciphertextB64: Buffer.from('ciphertext').toString('base64')
  };
  const resp = await client.post('/send-message', payload, { headers: { Authorization: 'Bearer ' + token } });
  console.log('send-message ->', resp.data);
}

async function fetchMessages(userId, token){
  const resp = await client.get('/messages/' + encodeURIComponent(userId), { headers: { Authorization: 'Bearer ' + token } });
  console.log('messages for', userId, '->', resp.data);
}

async function run(){
  try {
    const alice = 'alice', bob = 'bob', pwd='StrongPassw0rd!';
    await registerUser(alice, pwd);
    await registerUser(bob, pwd);
    const aliceToken = await loginUser(alice, pwd);
    const bobToken = await loginUser(bob, pwd);
    await registerPublicKey(alice, aliceToken);
    await registerPublicKey(bob, bobToken);
    await sendMessage(alice, bob, aliceToken);
    // wait a bit
    await sleep(500);
    await fetchMessages(bob, bobToken);
    // test backup: only allowed for admin by default; try as alice (should be forbidden)
    try {
      const resp = await client.post('/backup', {}, { headers: { Authorization: 'Bearer ' + aliceToken } });
      console.log('backup as alice ->', resp.data);
    } catch (e) {
      console.log('backup as alice -> expected failure:', e.response ? e.response.data : e.message);
    }
    console.log('Test sequence completed.');
  } catch (e) {
    console.error('Test failed:', e.response ? e.response.data : e.message);
  }
}

run();